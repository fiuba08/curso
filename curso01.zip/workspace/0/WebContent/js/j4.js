$("#content").on("click", function() {
  $("*").css("box-sizing", $(this).text());
});

$("#border").on("click", function() {
  $("*").css("box-sizing", $(this).text());
});