function printString() {
	var pagina = "<link rel='stylesheet' href='../css/css_util.css'>" +
			"<link rel='stylesheet' href='../css/c3.css'>" +
			"<br/><div class='css-container css-blue'><a href='p3.html'>Original</a></div><br/>";
	var paginaAdd = " Imprmir linea Hola :::";
	var mgs = "Mensaje Ingresado: "
	var texto = document.getElementById("entrada").value;
	if (texto.length != 0) {
		
		document.write(pagina);
		document.writeln(paginaAdd);
		document.writeln("<p  class='css-container css-blue css-center css-jumbo' id='salida'></p>");
		document.getElementById("salida").innerHTML = "Texto salida";
		document.write(mgs + texto);
	} else {
		document.write(pagina);
		document.writeln("<p class='css-red css-center css-jumbo' id='error'/>");
		document.getElementById("error").innerHTML = "Intorducir texto";
	}
}
