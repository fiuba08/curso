
  const h1 = document.getElementsByTagName('h1')[0];
  const p = document.getElementsByTagName('p')[0];
  const ul = document.getElementsByTagName('ul')[0];
  
  /*Listar Nodos*/
  function listarNode() {
	  var c = document.body.childNodes;
	  var txt = " ";
	  var txt1="Type : "
	  var i;
	  for (i = 0; i < c.length; i++) {
		txt = txt +"Nombre:" + c[i].nodeName + "- Type : ";
	    txt = txt + c[i].nodeType + "<br>";
	  }

	  document.getElementById("resultado").innerHTML = txt;
	}