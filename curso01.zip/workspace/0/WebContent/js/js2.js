//script type="text/javascript"
//PruebaCanva
       var i = 0.01;
            var Color = "Red";
            var x = 75;                // x coordinate
            var y = 75;                // y coordinate
            var radius = 20;                    // Arc radius
            var startAngle = 0;                     // Starting point on circle
            var anticlockwise = false; // clockwise or anticlockwise
window.onload = function(){
			var canvas = document.getElementById("PruebaGarfo");
			var ctx = canvas.getContext("2d");
			ctx.beginPath();
			ctx.arc(95,50,40,0,2*Math.PI);
			ctx.rotate(20 * Math.PI / 180);
			ctx.strokeStyle = "red";
			ctx.fillStyle = "green";
			ctx.fillRect(50, 20, 100, 50);
			//Linea
			ctx.moveTo(50, 150);
			ctx.lineTo(250, 50);
			//Linea de otro color
			
			ctx.fillStyle = "green";
			ctx.fillRect(50, 220, 200, 2);
			ctx.rotate(20 * Math.PI / 180)*80;
		
			ctx.translate(150, 25);
			ctx.fillStyle = "#ff0000";
			ctx.fillRect(10,10, 100,100);
			ctx.translate(150, 25);
			ctx.lineWidth   = 4;
			ctx.rotate( (Math.PI / 180) * 25); 
			ctx.strokeStyle = "#00AAff";
			ctx.strokeRect(30,20, 120,110);
			 ctx.beginPath();
			    ctx.moveTo(50,30);
			    ctx.lineTo(75,55);
			    ctx.lineTo(25,55);
			    ctx.lineTo(50,30);
			    ctx.lineWidth=2;
			//Propiedad de dibujar en el cotexto
			ctx.stroke();
		};
 

        function draw() {
     
            var canvas = document.getElementById('canvas');
            var ctx = canvas.getContext('2d');

                ctx.beginPath();
                var endAngle = i; // End point on circleMath.PI + (Math.PI * 5) /

                if (Math.floor(endAngle) >= 6) {
                    i = 0.01;
                    if (Color == "Red") {
                        Color = "blue";
                    } else {
                        Color = "Red";
                    }
                }

                ctx.strokeStyle = Color;
                ctx.arc(x, y, radius, startAngle, endAngle, anticlockwise);
                ctx.stroke();

                i = i + 0.05;
                document.getElementById('display').innerHTML = Math.floor(endAngle) + " " + Color;
    }
